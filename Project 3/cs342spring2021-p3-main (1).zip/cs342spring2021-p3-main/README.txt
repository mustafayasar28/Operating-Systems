
Include necessary information here, like names and IDs of groups members.



Note:

--- sbmem.h is the interface (header file) for the Library.
--- sbmemlib.c is the implementation of the library
--- You should include the header file sbmem.h in program (application) that will use your library.
--- You should compile and link the program with the library. The makefile is showing how
to do that. Look to "app" line in the Makefile.

